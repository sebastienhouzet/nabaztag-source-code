/*****************************************************************************
 *
 * irda-ioctl.h -  USB 2.0 IrDA Bridge 
 *              Private Ioctl Definition(s)
 *
 *  Copyright (C) 2004, SigmaTel, Inc. <irquality@sigmatel.com>
 *          
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place Ste 330, Boston MA 02111, USA
 *
 *
 * MODIFICATION HISTORY
 *
 *   DATE     WHO/WHAT
 *
 * 2004-07-29 SigmaTel, Inc.
 *            Support SigmaTel STIR42xx
 *
 ******************************************************************************/

#ifndef _IRDA_IOCTL_H_
#define _IRDA_IOCTL_H_

#ifndef SIOCDEVPRIVATE
#define SIOCDEVPRIVATE 0x89F0
#endif /* SIOCDEVPRIVATE */

#define PATCH_FILE_SIZE_MAX     65536
#define PATCH_FILE_SIZE_MIN     80
#define SIOCDEVPATCH42XX (SIOCDEVPRIVATE+016)

#endif // _IRDA_IOCTL_H_
