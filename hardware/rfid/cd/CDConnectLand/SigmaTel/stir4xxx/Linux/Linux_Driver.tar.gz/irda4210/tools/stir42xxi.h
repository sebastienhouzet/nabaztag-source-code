/*****************************************************************************
 *
 * stir42xxi.h - USB 2.0 IrDA Bridge Control Program
 *              Private Header File
 *
 *  Copyright (C) 2004, SigmaTel, Inc. <irquality@sigmatel.com>
 *          
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place Ste 330, Boston MA 02111, USA
 *
 *
 * MODIFICATION HISTORY
 *
 *   DATE     WHO/WHAT
 *
 * 2004-07-29 SigmaTel, Inc.
 *            Support SigmaTel STIR42xx
 *
 ******************************************************************************/

#ifndef _STIR42XXI_H_
#define _STIR42XXI_H_

#include "../irda-ioctl.h"

extern char *   myname ;
extern int      opt_quiet ;
extern int      opt_verbose ;
extern char *   opt_patchfile ;
extern char *   opt_ifname ;


extern void usage(void) ;
extern void getargs(int argc, char* argv[]) ;

#define NEVER_GETS_HERE() {}

#endif // _STIR42XXI_H_
