#!/bin/sh
tempfile=$HOME/mosx

if ( cp -f ./mos7703.ko /lib/modules/`uname -r`/kernel/drivers/usb/serial ) then
	echo "Installed"
else
	echo "Installation Failed"
fi

if(grep "modprobe usbserial" /etc/rc.local >>/dev/null) then
 echo ""
else 
 echo "modprobe usbserial" >> /etc/rc.local >>/dev/null
fi

if(grep "depmod -a" /etc/rc.local >> /dev/null)  then
 echo ""
else 
 echo depmod -a   >> /etc/rc.local
fi

modprobe usbserial >>/dev/null
depmod -a 2>>/dev/null
modprobe mos7703 2>>/dev/null
depmod  /lib/modules/`uname -r`/kernel/drivers/usb/serial/mos7703.ko 1>>/dev/null 2>>/dev/null
