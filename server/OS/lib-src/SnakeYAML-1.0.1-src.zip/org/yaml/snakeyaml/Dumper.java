/*
 * See LICENSE file in distribution for copyright and licensing information.
 */
package org.yaml.snakeyaml;

import java.io.Writer;
import java.util.Iterator;

import org.yaml.snakeyaml.emitter.Emitter;
import org.yaml.snakeyaml.error.YAMLException;
import org.yaml.snakeyaml.representer.Representer;
import org.yaml.snakeyaml.resolver.Resolver;
import org.yaml.snakeyaml.serializer.Serializer;

/**
 * @see <a href="http://pyyaml.org/wiki/PyYAML">PyYAML</a> for more information
 */
public class Dumper {
    private final Representer representer;
    private final DumperOptions options;

    public Dumper(Representer representer, DumperOptions options) {
        this.representer = representer;
        this.options = options;
    }

    /*protected Dumper(DumperOptions options) {
        this(new Representer(options.getDefaultStyle(), options.isDefaultFlowStyle()), options);
    }*/

    public void dump(Iterator<? extends Object> iter, Writer output, Resolver resolver) {
        Serializer s = new Serializer(new Emitter(output, options), resolver, options);
        try {
            s.open();
            while (iter.hasNext()) {
                representer.represent(s, iter.next());
            }
        } catch (java.io.IOException e) {
            throw new YAMLException(e);
        }
        try {
            s.close();
        } catch (java.io.IOException e) {
            throw new YAMLException(e);
        }
    }
}
