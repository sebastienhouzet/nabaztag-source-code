/*
 * See LICENSE file in distribution for copyright and licensing information.
 */
package org.yaml.snakeyaml.resolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.yaml.snakeyaml.nodes.Node;
import org.yaml.snakeyaml.nodes.ScalarNode;
import org.yaml.snakeyaml.nodes.SequenceNode;

/**
 * @see <a href="http://pyyaml.org/wiki/PyYAML">PyYAML</a> for more information
 */
public class Resolver {
    private static final String DEFAULT_SCALAR_TAG = "tag:yaml.org,2002:str";
    private static final String DEFAULT_SEQUENCE_TAG = "tag:yaml.org,2002:seq";
    private static final String DEFAULT_MAPPING_TAG = "tag:yaml.org,2002:map";

    private final Map<String, List<ResolverTuple>> yamlImplicitResolvers = new HashMap<String, List<ResolverTuple>>(128);

    public Resolver() {
        addImplicitResolver(
            "tag:yaml.org,2002:bool",
            Pattern.compile("^(?:yes|Yes|YES|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|Off|OFF)$"),
            "yYnNtTfFoO");
        addImplicitResolver(
            "tag:yaml.org,2002:float",
            Pattern.compile("^(?:[-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+][0-9]+)?|[-+]?(?:[0-9][0-9_]*)?\\.[0-9_]+(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),
            "-+0123456789.");
        addImplicitResolver(
            "tag:yaml.org,2002:int",
            Pattern.compile("^(?:[-+]?0b[0-1_]+|[-+]?0[0-7_]+|[-+]?(?:0|[1-9][0-9_]*)|[-+]?0x[0-9a-fA-F_]+|[-+]?[1-9][0-9_]*(?::[0-5]?[0-9])+)$"),
            "-+0123456789");
        addImplicitResolver(
    		"tag:yaml.org,2002:merge",
    		Pattern.compile("^(?:<<)$"),
    		"<");
        addImplicitResolver(
        	"tag:yaml.org,2002:null",
        	Pattern.compile("^(?:~|null|Null|NULL| )$"),
            "~nN\0");
        addImplicitResolver(
        	"tag:yaml.org,2002:null",
        	Pattern.compile("^$"),
        	null);
        addImplicitResolver(
            "tag:yaml.org,2002:timestamp",
            Pattern.compile("^(?:[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]|[0-9][0-9][0-9][0-9]-[0-9][0-9]?-[0-9][0-9]?(?:[Tt]|[ \t]+)[0-9][0-9]?:[0-9][0-9]:[0-9][0-9](?:\\.[0-9]*)?(?:[ \t]*(?:Z|[-+][0-9][0-9]?(?::[0-9][0-9])?))?)$"),
            "12");
        addImplicitResolver(
        	"tag:yaml.org,2002:value",
        	Pattern.compile("^(?:=)$"),
        	"=");
        // The following implicit resolver is only for documentation purposes.
        // It cannot work
        // because plain scalars cannot start with '!', '&', or '*'.
        addImplicitResolver(
        	"tag:yaml.org,2002:yaml",
        	Pattern.compile("^(?:!|&|\\*)$"),
        	"!&*");
    }

    public void addImplicitResolver(final String tag, final Pattern regexp, final String firstLetters) {

    	final ResolverTuple resolverTuple = new ResolverTuple(tag, regexp);

        if (firstLetters == null) {
        	addImplicitResolver(null, resolverTuple);

        } else {
            final char[] chrs = firstLetters.toCharArray();

            for (int i = 0, j = chrs.length; i < j; i++) {
                final Character ch = new Character(chrs[i]);
                addImplicitResolver((ch == 0) ? "" : String.valueOf(ch), resolverTuple);
            }
        }
    }

    private void addImplicitResolver(final String inKey, final ResolverTuple inResolverTuple) {

		List<ResolverTuple> tuples = yamlImplicitResolvers.get(inKey);

		if (tuples == null) {
			synchronized(yamlImplicitResolvers) { // use only the synchronized block in that case
				tuples = yamlImplicitResolvers.get(inKey);

				if (tuples == null) {
					tuples = new ArrayList<ResolverTuple>(4);
					yamlImplicitResolvers.put(inKey, tuples);
				}
			}
		}

		tuples.add(inResolverTuple);
    }

    public String resolve(final Class<? extends Node> kind, final String value, final boolean implicit) {

        List<ResolverTuple> resolvers = null;

        if (kind.equals(ScalarNode.class) && implicit) {

            if ("".equals(value)) {
                resolvers = yamlImplicitResolvers.get("");

            } else {
                resolvers = yamlImplicitResolvers.get(String.valueOf(value.charAt(0)));
            }

            // try the implicit resolvers..
            if (resolvers != null) {
                for (int i = 0, len = resolvers.size(); i < len; i++) { // avoid concurrent modification exception that could arise with an iterator

                	ResolverTuple resolver = resolvers.get(i);
                    if (resolver.getRegexp().matcher(value).matches()) {
                        return resolver.getTag();
                    }
                }
            }

            // we are here, and we have not resolved anything.. try the null resolvers
            resolvers = yamlImplicitResolvers.get(null);
            if (resolvers != null) {
                for (int i = 0, len = resolvers.size(); i < len; i++) { // avoid concurrent modification exception that could arise with an iterator

                	ResolverTuple resolver = resolvers.get(i);
                    if (resolver.getRegexp().matcher(value).matches()) {
                        return resolver.getTag();
                    }
                }
            }
        }

        if (kind.equals(ScalarNode.class)) {
            return DEFAULT_SCALAR_TAG;

        } else if (kind.equals(SequenceNode.class)) {
            return DEFAULT_SEQUENCE_TAG;
        }

        return DEFAULT_MAPPING_TAG;
    }

}
