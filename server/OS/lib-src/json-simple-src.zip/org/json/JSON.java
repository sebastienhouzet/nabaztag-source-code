//----------------------------------------------------------------------------79
// @(#) $Header: /vnb2/smile-fwk-2.0/src/org/json/JSON.java,v 1.1 2007/10/26 10:30:19 cdesguez Exp $
// Auteur          : CHDES
// Date creation   : 31 mai 2006
//----------------------------------------------------------------------------79
package org.json;

/**
 * @author CHDES
 *
 * Ensure that the object is serializable with the 'toJSONString()' method
 */
public interface JSON {
    
    public String toJSONString();
    
}
