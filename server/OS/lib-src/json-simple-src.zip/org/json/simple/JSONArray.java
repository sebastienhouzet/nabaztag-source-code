package org.json.simple;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.serializer.JSONSerializer;


/**
 * A JSONArray is a List that implements the JSON interface
 * In addition, it provide 2 static methods for the serialization of any List
 * with the optional ability to raise an exception if some items within the List cannot be serialized
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONArray extends ArrayList<Object> implements org.json.JSON {

	private static final long serialVersionUID = -8179629305694998503L;

//  -------------------------------------------------------------------------80

	public JSONArray() {
        super();
    }

    public JSONArray(int initialCapacity) {
        super(initialCapacity);
    }

//  -------------------------------------------------------------------------80
    /**
     * La representation de cet objet au format JSON
     */
    public String toJSONString() {
		return (new JSONSerializer()).serialize((List<Object>)this);
	}

    /**
     * @see java.lang.Object#toString()
     */
    @Override
	public String toString() {
        return toJSONString();
    }

}
