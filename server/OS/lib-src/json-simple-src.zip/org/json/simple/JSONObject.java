package org.json.simple;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.simple.serializer.JSONSerializer;

/**
 * A JSONObject is a Map that implements the JSON interface
 * In addition, it provide 2 static methods for the serialization of any Map
 * with the optional ability to raise an exception if some items within the Map cannot be serialized
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONObject extends HashMap<String, Object>  implements org.json.JSON {

	private static final long serialVersionUID = 1850013537806718605L;

//  -------------------------------------------------------------------------80

    /**
     * internal representation of the NULL object
     */
    private static class JSONNullObject extends JSONObject {
		private static final long serialVersionUID = 2961342962485525289L;

		protected JSONNullObject() {
        }
        @Override
		public String toJSONString() {
            return "null";
        }
    }

    public final static JSONNullObject NULL = new JSONObject.JSONNullObject();


//  -------------------------------------------------------------------------80
    /**
     * @return the JSON representation of this object/hashmap
     */
    public String toJSONString() {
		return (new JSONSerializer(true)).serialize((Map<String, Object>)this);
	}

    @Override
	public String toString() {
        return toJSONString();
    }


//  -------------------------------------------------------------------------80
// Some helper methods to directly retrieve key values in the expected format

    /**
     * @param string
     * @return
     */
    public JSONArray getJSONArray(String key) throws JSONException {
        try {
            return (JSONArray) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve JSON array object field under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public JSONObject getJSONObject(String key) throws JSONException {
        try {
            return (JSONObject) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve JSON object field under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public String getString(String key) throws JSONException {

        try {
            Object value = get(key);
            if (value != null) {
                return value.toString();
            } else {
                return null;
            }

        } catch (Exception e) {
            throw new JSONException("Unable to retrieve String value under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public Date getDate(String key) throws JSONException {
        try {
            return (Date) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve Date value under key " + key + "\n" + this.toString(), e);
        }
    }

}
