package org.json.simple.serializer;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONException;


/**
 * A variation of the JSON format which adds custom 'meta' attributes
 * containing the type of the map (the class name)
 * which may be used to infer the struture of the map.
 *
 * @author christophe - Violet
 */
public class JSONCustomSerializer extends JSONSerializer {

	public final static String DEFAULT_TYPE_ATTRIBUTE = "!!TYPE";

	private final String mTypeAttribute;
	private final boolean mUseSilentMode;

	public JSONCustomSerializer() {
		mTypeAttribute = DEFAULT_TYPE_ATTRIBUTE;
		mUseSilentMode = false;
	}
	public JSONCustomSerializer(String typeAttribute, boolean inSilentMode) {
		mTypeAttribute = typeAttribute;
		mUseSilentMode = inSilentMode;
	}

//  -------------------------------------------------------------------------80
	/**
	 * @param map
	 * @return a JSON String where malformed items have been dropped
	 */
	@Override
	public String serialize(Map<String, Object> map) throws JSONException {

		if (map == null) {
			return "null";
		}

		Iterator<Entry<String, Object>> iter = map.entrySet().iterator();

		StringBuilder sb = new StringBuilder(24 * map.size());
		int lastLength = 0;

		sb.append("{");

		// Add the type of the structure as a meta attribute
		append(mTypeAttribute, sb);
		sb.append(":");
		append(map.getClass().getSimpleName(), sb);

		// now, add the 'legitimate' attributes
		while (iter.hasNext()) {
			Map.Entry<String, Object> entry = iter.next();
			lastLength = sb.length(); // remember the position to cancel if an exception occurs

			try {
				sb.append(",");
				append(entry.getKey(), sb);
				sb.append(":");
				append(entry.getValue(), sb);

			} catch (JSONException jse) {
				if (mUseSilentMode) {
					// erase what we could have appended before the exception occured
					sb.setLength(lastLength);
				} else {
					throw jse;
				}
			}
		}

		sb.append("}");
		return sb.toString();

	}

}
