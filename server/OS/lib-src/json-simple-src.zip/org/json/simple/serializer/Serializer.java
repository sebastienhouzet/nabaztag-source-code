package org.json.simple.serializer;

import org.json.JSONException;

/**
 *
 * @author christophe - Violet
 */
public interface Serializer {

	String serialize(Object in) throws JSONException;

}
