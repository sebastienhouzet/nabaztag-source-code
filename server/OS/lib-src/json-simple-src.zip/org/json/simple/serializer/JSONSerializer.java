package org.json.simple.serializer;

import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSON;
import org.json.JSONException;
import org.json.helper.JsonDateHelper;

/**
 * @author christophe - Violet
 */
public class JSONSerializer implements Serializer {

	private final boolean mUseSilentMode;

	public JSONSerializer() {
		mUseSilentMode = false;
	}

	public JSONSerializer(boolean inSilentMode) {
		mUseSilentMode = inSilentMode;
	}

	public boolean useSilentMode() {
		return mUseSilentMode;
	}

//  -------------------------------------------------------------------------80

	/**
	 * @param inText
	 * @return the JSON String representation
	 */
	public String serialize(String inText) throws JSONException {

		if (inText == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder(inText.length() + 10);
		append(inText, sb);
		return sb.toString();
	}
	/**
	 * Append the JSON String representation to an existing StringBuilder
	 * @param inStr the String to serialize. (MUST NOT BE NULL !)
	 * @param sbOut the StringBuilder to append into. (MUST NOT BE NULL !)
	 * @TODO Optimize the switch case with a simple lookup in a static char array
	 */
	protected void append(String inStr, StringBuilder sbOut) {

		char[] chars = inStr.toCharArray();
		int len = chars.length;

		sbOut.append('"');

		for (int i = 0; i < len; i++) {
			char ch = chars[i];
			switch (ch) {
			case '"':
				sbOut.append("\\\"");
				break;
			case '\\':
				sbOut.append("\\\\");
				break;
			case '\n':
				sbOut.append("\\n");
				break;
			case '\r':
				sbOut.append("\\r");
				break;
			case '\t':
				sbOut.append("\\t");
				break;
			case '\b':
				sbOut.append("\\b");
				break;
			case '\f':
				sbOut.append("\\f");
				break;
			case '/':
				sbOut.append("\\/");
				break;

			default:
				if (ch >= '\u0000' && ch <= '\u001F') {
					String ss = Integer.toHexString(ch);
					sbOut.append("\\u");
					for (int k = 0; k < 4-ss.length(); k++) {
						sbOut.append('0');
					}
					sbOut.append(ss.toUpperCase());

				} else {
					sbOut.append(ch);
				}
			}
		}//for

		sbOut.append('"');

	}

//  -------------------------------------------------------------------------80
	/**
	 * @param inDate
	 * @return the JSON Date representation
	 */
	public String serialize(Date inDate) throws JSONException {
		if (inDate == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder(24); // we know the length of the Date representation
		append(inDate, sb);
		return sb.toString();
	}
	/**
	 * Append the JSON Date representation to an existing StringBuilder
	 * @param inDate the Date to serialize. (MUST NOT BE NULL !)
	 * @param sbOut the StringBuilder to append into. (MUST NOT BE NULL !)
	 * @TODO Optimize the switch case with a simple lookup in a static char array
	 */
	protected void append(Date inDate, StringBuilder sbOut) {
		sbOut.append('"');
		sbOut.append(JsonDateHelper.formatDate(inDate));
		sbOut.append('"');
	}

//  -------------------------------------------------------------------------80
	/**
	 * @param inBoolean
	 * @return
	 */
	public String serialize(Boolean inBoolean) throws JSONException {
		return (inBoolean == null) ? "null" : String.valueOf(inBoolean);
	}

	/**
	 * @param inNumber
	 * @return the JSON representation
	 */
	public String serialize(Number inNumber) throws JSONException {
		return (inNumber == null) ? "null" : String.valueOf(inNumber);
	}

	/**
	 * @param inJSON an object implementing the JSON serialization interface
	 * @return the JSON representation
	 */
	public String serialize(JSON inJSON) throws JSONException {
		return (inJSON == null) ? "null" : inJSON.toJSONString();
	}

//  -------------------------------------------------------------------------80

	/**
	 * @param inMap
	 * @return the JSON String representing this structure
	 * Note : malformed items may have been dropped depending of the silent mode
	 * @throws JSONException when not in silent mode
	 */
	public String serialize(Map<String, Object> inMap) throws JSONException {

		if (inMap == null) {
			return "null";
		}

		Iterator<Entry<String, Object>> iter = inMap.entrySet().iterator();

		StringBuilder sb = new StringBuilder(24 * inMap.size());
		int lastLength = 0;
		boolean addSep = false; // add the separator ?

		sb.append("{");

		while (iter.hasNext()) {
			Map.Entry<String, Object> entry = iter.next();
			lastLength = sb.length(); // remember the position to cancel if an exception occurs

			try {
				if (addSep) {
					sb.append(",");
				}
				append(entry.getKey(), sb);
				sb.append(":");
				append(entry.getValue(), sb);

				addSep = true;

			} catch (JSONException jse) {
				if (mUseSilentMode) {
					// erase what we could have appended before the exception occured
					sb.setLength(lastLength);
				} else {
					throw jse;
				}
			}
		}

		sb.append("}");
		return sb.toString();

	}

//  -------------------------------------------------------------------------80
	/**
	 * @param inList
	 * @return a JSON String "[..]"
	 * @throws JSONException when not in silent mode
	 */
	public String serialize(List<Object> inList) throws JSONException {

		if (inList == null) {
			return "null";
		}

		Iterator<Object> iter = inList.iterator();

		StringBuilder sb = new StringBuilder(16 * inList.size());
		int lastLength = 0;
		boolean addSep = false; // add the separator ?

		sb.append("[");

		while (iter.hasNext()) {
			Object listItem = iter.next();
			lastLength = sb.length(); // remember the position to cancel if an exception occurs

			try {
				if (addSep) {
					sb.append(",");
				}
				append(listItem, sb);

				addSep = true; // at least on item has been added

			} catch (JSONException jse) {
				if (mUseSilentMode) {
					// erase what we could have appended before the exception occured
					sb.setLength(lastLength);
				} else {
					throw jse;
				}
			}
		}

		sb.append("]");
		return sb.toString();

	}

	/**
	 * @param array
	 * @return a JSON String "[..]"
	 * @throws JSONException when not in silent mode
	 */
	public String serialize(Object[] array) throws JSONException {

		if (array == null) {
			return "null";
		}

		return serialize(Arrays.asList(array));
	}

//  -------------------------------------------------------------------------80
	/**
	 * The caller didn't provide the type of the Object, but it can still be one
	 * of our accepted POJO type !
	 *
	 * @see org.json.simple.serializer.Serializer#serialize(java.lang.Object)
	 */
	public String serialize(Object unrecognizedType) throws JSONException {

		if (unrecognizedType == null) {
			return "null";

		} else if (unrecognizedType instanceof JSON) { // in first position because an object implementing map or list can have its own dedicated deserialization method
			return serialize((JSON) unrecognizedType);

		} else if (unrecognizedType instanceof Map) {
			return serialize((Map<String, Object>) unrecognizedType);

		} else if (unrecognizedType instanceof String) {
			return serialize((String) unrecognizedType);

		} else if (unrecognizedType instanceof List) {
			return serialize((List<Object>) unrecognizedType);

		} else if (unrecognizedType instanceof Boolean) {
			return serialize((Boolean) unrecognizedType);

		} else if (unrecognizedType instanceof Number) {
			return serialize((Number) unrecognizedType);

		} else if (unrecognizedType instanceof Date) {
			return serialize((Date) unrecognizedType);

		} else if (unrecognizedType instanceof Object[]) {
			return serialize((Object[]) unrecognizedType);

		} else {
			throw new JSONException("Object " + unrecognizedType
				+ "(" + unrecognizedType.getClass().getSimpleName()
				+ ") is not of one of the expected types !\n"
				+ "Supported types are Map, List, Object[], String, Number, Boolean, Date "
				+ "and objects implementing the JSON interface.");
		}
	}

	/**
	 * The same, but using an existing StringBuilder
	 * @param key
	 * @param value
	 * @throws JSONException
	 */
	@SuppressWarnings("unchecked")
	protected void append(Object value, StringBuilder sbOut) throws JSONException {

		if (value == null) {
			sbOut.append("null");

		} else if (value instanceof JSON) { // in first position because an object implementing map or list can have its own dedicated deserialization method
			sbOut.append(((JSON) value).toJSONString());

		} else if (value instanceof Map) {
			sbOut.append(serialize((Map) value));

		} else if (value instanceof String) {
			append((String) value, sbOut);

		} else if (value instanceof List) {
			sbOut.append(serialize((List) value));

		} else if (value instanceof Object[]) {
			sbOut.append(serialize((Object[]) value));

		} else if (value instanceof Date) {
			append((Date) value, sbOut);

		} else if ((value instanceof Boolean) || (value instanceof Number)) {
			sbOut.append(String.valueOf(value));

		} else {
			throw new JSONException("Object " + value + " is not of one of the expected types !\n" + "Supported types are Map, List, Object[], String, Number, Boolean, Date and objects implementing the JSON interface.");
		}

	}

}
