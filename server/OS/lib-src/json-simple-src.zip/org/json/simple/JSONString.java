package org.json.simple;

import org.json.JSON;
import org.json.simple.serializer.JSONSerializer;

/**
 * A simple String encapsulation to render it in JSON.
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONString implements JSON {

    private final String str;

    public JSONString(String str) {
        this.str = str;
    }

    /*
     * @see org.json.JSON#toJSONString()
     */
    public String toJSONString() {
        return (new JSONSerializer()).serialize(this.str);
    }

}
