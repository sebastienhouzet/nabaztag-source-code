package org.json.simple;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.json.JSON;
import org.json.simple.serializer.JSONSerializer;

/**
 * JSONObjectWrapper serves the same purpose as JSONObject,
 * but is more suitable when the Map is allready built : just wrap it !
 *
 */
public class JSONObjectWrapper implements Map<String, Object>, JSON {

	private final Map<String, Object> map;

//  -------------------------------------------------------------------------80
	/**
	 * @param map
	 */
	public JSONObjectWrapper(Map<String, Object> map) {
		super();
		this.map = map;
	}

	/**
	 * Implements the JSON interface
	 * @see org.json.JSON#toJSONString()
	 */
	public String toJSONString() {
		return (new JSONSerializer()).serialize(map);
	}

//  -------------------------------------------------------------------------80
	/**
	 * @see org.mozilla.javascript.Wrapper#unwrap()
	 */
	public Object unwrap() {

		return this.map;
	}

//  -------------------------------------------------------------------------80
	/**
	 * Implements the Map interface
	 */
	public void clear() {
		this.map.clear();
	}

	public boolean containsKey(Object key) {
		return this.map.containsKey(key);
	}

	public boolean containsValue(Object value) {
		return this.map.containsValue(value);
	}

	public Set<Entry<String, Object>> entrySet() {
		return this.map.entrySet();
	}

	public Object get(Object key) {
		return this.map.get(key);
	}

	public boolean isEmpty() {
		return this.map.isEmpty();
	}

	public Set<String> keySet() {
		return this.map.keySet();
	}

	public Object put(String key, Object value) {
		return this.map.put(key.toString(), value);
	}

	public void putAll(Map map) {
		this.map.putAll(map);
	}

	public Object remove(Object key) {
		return this.map.remove(key);
	}

	public int size() {
		return this.map.size();
	}

	public Collection<Object> values() {
		return this.map.values();
	}

//  -------------------------------------------------------------------------80

}
