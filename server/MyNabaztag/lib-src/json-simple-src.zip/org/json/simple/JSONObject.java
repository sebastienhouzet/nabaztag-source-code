package org.json.simple;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSON;
import org.json.JSONException;
import org.json.helper.JsonDateHelper;

/**
 * A JSONObject is a Map that implements the JSON interface
 * In addition, it provide 2 static methods for the serialization of any Map
 * with the optional ability to raise an exception if some items within the Map cannot be serialized
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONObject extends HashMap<String, Object>  implements org.json.JSON {

	private static final long serialVersionUID = 1850013537806718605L;

//  -------------------------------------------------------------------------80

    /**
     * internal representation of the NULL object
     */
    private static class JSONNullObject extends JSONObject {
		private static final long serialVersionUID = 2961342962485525289L;

		protected JSONNullObject() {
        }
        @Override
		public String toJSONString() {
            return "null";
        }
    }

    public final static JSONNullObject NULL = new JSONObject.JSONNullObject();

//  -------------------------------------------------------------------------80

    /**
     * @param map
     * @return a JSON String where malformed items have been dropped
     */
    public static String serialize(Map<String, Object> map) {
    	try {
			return JSONObject.serialize(map, true);
		} catch (JSONException ignore) {
			// in silent mode we cannot be here !
			return "";
		}
    }

    /**
     * @param map
     * @param silentMode TRUE to silently drop malformed item
     * @return the JSON representation of this structure
     * @throws JSONException
     */
    public static String serialize(Map<String, Object> map, boolean silentMode)
    throws JSONException {

    	if (map == null) {
    		return "null";
    	}

		Iterator<Entry<String, Object>> iter = map.entrySet().iterator();

		StringBuilder sb = new StringBuilder(24*map.size());
		int lastLength = 0;
		boolean addSep = false; // add the separator ?

		sb.append("{");

		while (iter.hasNext()) {
			Map.Entry<String, Object> entry = iter.next();
			lastLength = sb.length(); // remember the position to cancel if an exception occurs

			try {
				if (addSep) {
					sb.append(",");
				}
				writeValue( entry.getKey(), sb, silentMode );
				sb.append(":");
				writeValue( entry.getValue(), sb, silentMode );

				addSep = true;

			} catch (JSONException jse) {
				if (silentMode) {
					// erase what we could have appended before the exception occured
					sb.setLength(lastLength);
				} else {
					throw jse;
				}
			}
		}

		sb.append("}");
		return sb.toString();

    }

//  -------------------------------------------------------------------------80
    /**
     * @return the JSON representation of this object/hashmap
     */
    public String toJSONString() {
		return JSONObject.serialize(this);
	}

    @Override
	public String toString() {
        return toJSONString();
    }

//  -------------------------------------------------------------------------80
	/**
     * @param key
     * @param value
     * @return the JSON representation of this key/value pair object/hashmap
	 * @throws JSONException
     */
    @SuppressWarnings("unchecked")
	protected static void writeValue(Object value, StringBuilder sbOut, boolean silentMode) throws JSONException {

    	if (value == null) {
    		sbOut.append( "null" );

    	} else if (value instanceof JSON) { // in first position because an object implementing map or list can have its own dedicated deserialization method
    		sbOut.append( ((JSON) value).toJSONString() );

    	} else if (value instanceof Map) {
			sbOut.append( JSONObject.serialize((Map) value, silentMode) );

		} else if (value instanceof String) {
			sbOut.append( JSONString.serialize((String) value) );

		} else if (value instanceof List) {
			sbOut.append( JSONArray.serialize((List) value, silentMode) );

		} else if (value instanceof Object[]) {
			sbOut.append( JSONArray.serialize((Object[]) value, silentMode) );

		} else if (value instanceof Date) {
			sbOut.append( "\"" );
			sbOut.append( JsonDateHelper.formatDate((Date) value) );
			sbOut.append( "\"" );

		} else if ((value instanceof Boolean) || (value instanceof Number)) {
			sbOut.append( String.valueOf(value) );

		} else {
			throw new JSONException("Object " + value + " is not of one of the expected types !\n" +
					"Supported types are Map, List, Object[], String, Number, Boolean, Date and objects implementing the JSON interface.");
		}

	}

//  -------------------------------------------------------------------------80
// Some helper methods to directly retrieve key values in the expected format

    /**
     * @param string
     * @return
     */
    public JSONArray getJSONArray(String key) throws JSONException {
        try {
            return (JSONArray) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve JSON array object field under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public JSONObject getJSONObject(String key) throws JSONException {
        try {
            return (JSONObject) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve JSON object field under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public String getString(String key) throws JSONException {

        try {
            Object value = get(key);
            if (value != null) {
                return value.toString();
            } else {
                return null;
            }

        } catch (Exception e) {
            throw new JSONException("Unable to retrieve String value under key " + key + "\n" + this.toString(), e);
        }
    }

    /**
     * @param string
     * @return
     */
    public Date getDate(String key) throws JSONException {
        try {
            return (Date) get(key);
        } catch (Exception e) {
            throw new JSONException("Unable to retrieve Date value under key " + key + "\n" + this.toString(), e);
        }
    }

}
