package org.json.simple;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;


/**
 * A JSONArray is a List that implements the JSON interface
 * In addition, it provide 2 static methods for the serialization of any List
 * with the optional ability to raise an exception if some items within the List cannot be serialized
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONArray extends ArrayList<Object> implements org.json.JSON {

	private static final long serialVersionUID = -8179629305694998503L;

//  -------------------------------------------------------------------------80

	public JSONArray() {
        super();
    }

    public JSONArray(int initialCapacity) {
        super(initialCapacity);
    }

//  -------------------------------------------------------------------------80

    /**
     * @param list
     * @return a JSON String where malformed items have been dropped
     */
    public static String serialize(List<Object> list) {
    	try {
			return JSONArray.serialize(list, true);
		} catch (JSONException ignore) {
			// in silent mode we cannot be here !
			return "";
		}
    }

    /**
     * @param list
     * @param silentMode : set to TRUE to silently drop malformed items
     * @return a JSON String "[..]"
     * @throws JSONException
     */
    public static String serialize(List<Object> list, boolean silentMode)
    throws JSONException {

    	if (list == null) {
    		return "null";
    	}

    	Iterator<Object> iter = list.iterator();

		StringBuilder sb = new StringBuilder(16*list.size());
		int lastLength = 0;
		boolean addSep = false; // add the separator ?

		sb.append("[");

		while (iter.hasNext()) {
			Object value = iter.next();
			lastLength = sb.length(); // remember the position to cancel if an exception occurs

			try {
				if (addSep) {
					sb.append(",");
				}
				JSONObject.writeValue( value, sb, silentMode );

				addSep = true; // at least on item has been added

			} catch (JSONException jse) {
				if (silentMode) {
					// erase what we could have appended before the exception occured
					sb.setLength(lastLength);
				} else {
					throw jse;
				}
			}
		}

		sb.append("]");
		return sb.toString();

    }

    /**
     * @param array
     * @return a JSON String where malformed items have been dropped
     */
    public static String serialize(Object[] array) {
    	final List<Object> list = Arrays.asList(array);
    	try {
			return JSONArray.serialize(list, true);
		} catch (JSONException ignore) {
			// in silent mode we cannot be here !
			return "";
		}
    }

    /**
     * @param array
     * @param silentMode : TRUE to silently drop malformed items
     * @return a JSON String "[..]"
     */
    public static String serialize(Object[] array, boolean silentMode)
    throws JSONException {
    	final List<Object> list = Arrays.asList(array);
    	try {
			return JSONArray.serialize(list, silentMode);
		} catch (JSONException ignore) {
			// in silent mode we cannot be here !
			return "";
		}
    }

//  -------------------------------------------------------------------------80
    /**
     * La representation de cet objet au format JSON
     */
    public String toJSONString() {
		return JSONArray.serialize(this);
	}

    /**
     * @see java.lang.Object#toString()
     */
    @Override
	public String toString() {
        return toJSONString();
    }

}
