package org.json.simple;

import org.json.JSON;

/**
 * A simple String encapsulation to render it in JSON.
 *
 * @author chdes - Violet
 * based on the primary work of FangYidong<fangyidong@yahoo.com.cn>
 */
public class JSONString implements JSON {

    private final String str;

    public JSONString(String str) {
        this.str = str;
    }

//  -------------------------------------------------------------------------80

    /**
     * @param str
     * @return
     */
    public static String serialize(String str) {
    	return (str == null) ? "null" : '\"' + JSONString.escape(str) + '\"';
    }

    /*
     * @see org.json.JSON#toJSONString()
     */
    public String toJSONString() {
        return JSONString.serialize(this.str);
    }

//  -------------------------------------------------------------------------80
	/**
	 * " => \" , \ => \\
	 * @param inStr
	 * @return
	 */
	public static String escape(String inStr) {

		if (inStr == null) {
            return null;
		}

		char[] chars = inStr.toCharArray();
		int len = chars.length;

		// guess how many chars we'll have to escape
		StringBuilder sb = new StringBuilder(len + 10);

		for (int i = 0; i < len; i++) {
			char ch = chars[i];
			switch (ch) {
			case '"':
				sb.append("\\\"");
				break;
			case '\\':
				sb.append("\\\\");
				break;
			case '\n':
				sb.append("\\n");
				break;
			case '\r':
				sb.append("\\r");
				break;
			case '\t':
				sb.append("\\t");
				break;
			case '\b':
				sb.append("\\b");
				break;
			case '\f':
				sb.append("\\f");
				break;
			case '/':
				sb.append("\\/");
				break;

			default:
				if (ch >= '\u0000' && ch <= '\u001F') {
					String ss = Integer.toHexString(ch);
					sb.append("\\u");
					for (int k = 0; k < 4-ss.length(); k++) {
						sb.append('0');
					}
					sb.append(ss.toUpperCase());

				} else {
					sb.append(ch);
				}
			}
		}//for
		return sb.toString();
	}

}
