package org.json.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility Class to resolve the Date problem in JSON format.
 *
 * Dates must be passed as strings in the ISO 8601 format, in the UTC Time Zone
 * Therefore, the date format is : YYYY-MM-DDThh:mm:ssZ
 * (where the 'T' time symbol and 'Z' for Zulu/UTC time are mandatory)
 *
 * We use a regular expression to determine if some input String contains a ISO 8601 conformant Date,
 * and provide some parse/format utility methods
 *
 * @author chdes - Violet
 *
 */
public class JsonDateHelper {

    // internal date formatter
	private final static SimpleDateFormat ISO_8601_DateFormater;
	static {
		ISO_8601_DateFormater = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		ISO_8601_DateFormater.setTimeZone(TimeZone.getTimeZone("UTC")); // Zulu time is UTC, (or Greenwich Meridian Time)
	}

    // internal Regular expression to check Strings against this format
    private final static Pattern ISO_8601_DatePattern = Pattern.compile("(\\d{4}-\\d{2}-\\d{2}[T ]{1}\\d{2}:\\d{2}:\\d{2}(Z|[+-]{1}\\d{4}|[+-]{1}\\d{2}|[A-Z]{3})?)");

//  -------------------------------------------------------------------------80
    /**
     * @param inStr
     * @return TRUE if the inStr IS a date in ISO 8601 format
     */
    public static boolean isJsonDate(String inStr) {

    	if (inStr == null) { // JSON dates are expected at least in the full YYYY-MM-DD HH:MM:SSZ form
			return false;
		}

    	return ISO_8601_DatePattern.matcher(inStr).matches();
    }

    /**
     * A good guess about a JSON date to ellude the need of the full regular expression matching
     * Should give good response in 90% of the cases, and then we rely on the failing of the parsing
     * JSON dates are expected at least in the full YYYY-MM-DD HH:MM:SSZ form
     * but timezone may be expressed in the +/-00:00 form too
     * @param inStr
     * @return TRUE if the inStr LOOKS LIKE a date in ISO 8601 full format
     */
    public static boolean guessJsonDate(String inStr) {

    	if ((inStr == null) || (inStr.length() < 19)) { // minimal length without the timezone
			return false;
		}

    	char firstDigit = inStr.charAt(0);
    	return (firstDigit == '1' || firstDigit == '2'); // accept only dates in the 1st or 2nd millenary

    	/* more precise verification should check that the characters are only digits or accepted separators
    	for (char c: inStr.toCharArray()) {
    		if (c >= '0' && c <= '9') continue; // digit
    		if (c == '-' || c == ':' || c == ' ' || c == 'T') continue; // separator
    		return false;
    	}
    	return true;*/
    }

    /**
     * @param inStr
     * @return TRUE if the inStr CONTAINS some date(s) in the ISO 8601 format
     */
    public static boolean containsDate(String inStr) {

    	if (inStr == null) {
			return false;
		}

    	Matcher match = ISO_8601_DatePattern.matcher(inStr);
    	return match.find();
    }

    /**
     * @param inDate
     * @return the date in ISO 8601 UTC format
     */
    public static String formatDate(Date inDate) {

    	if (inDate == null) {
    		return "null";
    	}

    	return JsonDateHelper.ISO_8601_DateFormater.format(inDate);
    }

    /**
     * @param inStr represent a date in ISO 8601 UTC format
     * @return the parsed Date
     * @throws ParseException
     */
    public static Date parseDate(String inStr) throws ParseException {

    	// enforce the full ISO 8601 date format with separators
		return ISO8601DateParser.parse(inStr, true);
    }

//  -------------------------------------------------------------------------80
    /**
     * Some unitary tests
     */
    public static void main(String[] args) {

    	try {
    		String now = JsonDateHelper.formatDate(new Date());
    		System.out.println("Now (in Zulu time) : " + now);

    		System.out.println("Reparsed again : " + JsonDateHelper.parseDate(now));

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

    }


}
