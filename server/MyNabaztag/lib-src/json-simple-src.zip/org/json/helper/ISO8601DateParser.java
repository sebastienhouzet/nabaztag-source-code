package org.json.helper;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Get rid of SimpleDateFormat for the parsing of ISO Dates !
 * (problems with timezones notably)
 *
 * We accept the following ISO forms :
 * - 2008 (a simple year)
 * - 2008-01 or 200801 (year + month)
 * - 2008-01-01 or 20080101 (date with separators or not)
 * - 2008-01-01 12:00:00 or 2008-01-01T12:00:00 or 20080101120000 (date and time with separators or not)
 * - 2008-01-01 12:00:00.004 (with milliseconds. takes only four decimals)
 * - 2008-01-01 12:00:00CST or 2008-01-01 12:00:00+0300 (with timezone, named or not)
 *
 * @author christophe - Violet
 */
public class ISO8601DateParser {

    /**
     * an inner classe to store the input string as a char array and consum it
     */
    static class CharArrayParser {

    	private final char[] mCharay;   // char array
    	private int mPos = 0;     // current parsing pos (next char to read)
    	private int mLength = -1; // char array

    	CharArrayParser(char[] inCars) {
    		mCharay = inCars;
    		mLength = inCars.length;
    	}
    	CharArrayParser(String inStrDate) {
    		mCharay = inStrDate.toCharArray();
    		mLength = inStrDate.length();
    	}

    	/**
    	 * a nice representation of myself during the parsing
    	 */
    	@Override
		public String toString() {
    		String mySelf = "";
    		for (int i = 0; i < mLength; i++) {
    			if (i == mPos) {
    				mySelf += ("[" + mCharay[i] + "]");
    			} else {
    				mySelf += mCharay[i];
    			}
    		}
    		return mySelf;
    	}

    	/**
    	 * Try to consum some digits or return the default value
    	 * @param inNbOfDigits number of digits to consum (may be less)
    	 * @param inDefaultValue
    	 * @return the decimal value of all digits read as a single number
    	 */
    	int consumDigits(int inNbOfDigits, int inDefaultValue) {

    		if (mPos == mLength) {
    			return inDefaultValue;
    		}

    		int value = 0, currentPos = mPos;

    		for (int i = 0; i < inNbOfDigits && mPos < mLength; i++) {
    			if (isDigit(mCharay[mPos])) {
    				value = 10*value + Character.digit(mCharay[mPos], 10);
    				mPos++;
    			} else {
    				break;
    			}
    		}

    		return (mPos == currentPos) ? inDefaultValue : value;
    	}

    	/**
    	 * Force the consumation of at least some digits
    	 * @param inNbOfDigits
    	 * @param required
    	 * @return the decimal value of all digits read as a single number
    	 * @throws ParseException
    	 */
    	int consumDigits(int inNbOfDigits, boolean required) throws ParseException {
    		int val = consumDigits(inNbOfDigits, -1);

    		if (required && val == -1) {
    			throw new ParseException("Unable to parse ISO date in input string : " + this, mPos);
    		}
    		return val;
    	}


    	/**
    	 * Consum some separation chars in the accepted range
    	 * @param inNbOfChars number of sep chars to consum (may be less if required=FALSE)
    	 * @param inAcceptedChars : only the given chars may be consumed
    	 * @param required : pass TRUE to require the presence of exactly inNbOfChars
    	 * @throws ParseException when required=TRUE and the expected sep chars are not found
    	 */
    	void consumSepChars(int inNbOfChars, String inAcceptedChars, boolean required) throws ParseException {

    		int currentPos = mPos;
    		char[] acceptedRange = inAcceptedChars.toCharArray();

    		for (int i = 0; i < inNbOfChars && mPos < mLength; i++) {
    			boolean accepted = false;

    			for (int j = 0; j < acceptedRange.length; j++) {
    				if (acceptedRange[j] == mCharay[mPos]) {
	    				accepted = true;
	    				break;
    				}
    			}

    			if (accepted) {
    				mPos++;
    			} else {
    				break;
    			}
    		}

    		if (required && (mPos - currentPos != inNbOfChars)) {
    			throw new ParseException("Unable to parse ISO date in input string : " + this, mPos);
    		}
    	}


    	String getRemaining() {
    		return new String(mCharay, mPos, mLength-mPos);
    	}

    	int getPosition() {
    		return mPos;
    	}

    	/**
    	 * Care only about 0..9 digits from ISO-LATIN-1
    	 * @param inChar
    	 * @return
    	 */
    	boolean isDigit(char inChar) {
    		return (inChar >= '0') && (inChar <= '9');
    	}
    }

    static class DateParts {

    	int year = 1900;
    	int month = 1;
    	int day = 1;
    	int hours = 0;
    	int minutes = 0;
    	int seconds = 0;
    	int ms = 0;
    	TimeZone tz = TimeZone.getTimeZone("UTC");

    	void setYear(int inYear) {
    		year = inYear;
    	}
    	void setMonth(int inMonth) {
    		if (inMonth > 12) {
				throw new IllegalArgumentException("Illegal month value for date : " + inMonth);
			}
    		month = inMonth;
    	}
    	void setDay(int inDay) {
    		if (inDay > 31) {
				throw new IllegalArgumentException("Illegal day value for date : " + inDay);
			}
    		day = inDay;
    	}
    	void setHours(int inHours) {
    		if (inHours > 23) {
				throw new IllegalArgumentException("Illegal hours value for date : " + inHours);
			}
    		hours = inHours;
    	}
    	void setMinutes(int inMinutes) {
    		if (inMinutes > 59) {
				throw new IllegalArgumentException("Illegal minutes value for date : " + inMinutes);
			}
    		minutes = inMinutes;
    	}
    	void setSeconds(int inSeconds) {
    		if (inSeconds > 59) {
				throw new IllegalArgumentException("Illegal seconds value for date : " + inSeconds);
			}
    		seconds = inSeconds;
    	}
    	void setMs(int inMs) {
    		ms = inMs;
    	}
		public void setTimezone(String inTimeZone) {
			if (inTimeZone != null && inTimeZone.length() > 0) {

				if (inTimeZone.startsWith("+") || inTimeZone.startsWith("-")) {
					if (!inTimeZone.contains(":")) {
						tz = TimeZone.getTimeZone("GMT" + inTimeZone.substring(0, 3) + ":" + inTimeZone.substring(3));
					} else {
						tz = TimeZone.getTimeZone("GMT" + inTimeZone);
					}

				} else {
					tz = TimeZone.getTimeZone(inTimeZone);
				}
			}
		}

    	Date toDate() {
    		Calendar cal = Calendar.getInstance(tz); // attention : Calendar est initialisé à l'heure courante : il faut tout initialiser

    		cal.set(Calendar.YEAR, year);
    		cal.set(Calendar.MONTH, month - 1);
    		cal.set(Calendar.DAY_OF_MONTH, day);
    		cal.set(Calendar.HOUR_OF_DAY, hours);
    		cal.set(Calendar.MINUTE, minutes);
    		cal.set(Calendar.SECOND, seconds);
    		cal.set(Calendar.MILLISECOND, ms);

    		return cal.getTime(); // uhh ?
    	}

    	@Override
		public String toString() {
    		return year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds + " " + tz.getDisplayName();
    	}

    }


    /**
     * @param inStrDate
     * @param forceSepChars pass TRUE to force the usage of sep chars
     * @return
     * @throws ParseException
     */
    public static Date parse(String inStrDate, boolean forceSepChars) throws ParseException {

    	if (inStrDate == null) {
    		return null;
    	}
    	CharArrayParser parser = new CharArrayParser(inStrDate);
    	DateParts myDateParts = new DateParts();

    	try {
	    	myDateParts.setYear(parser.consumDigits(4, true)); // force Parsing exception if we don't find 4 digits here
	    	parser.consumSepChars(1, "-", forceSepChars);
	    	myDateParts.setMonth(parser.consumDigits(2, 1));
	    	parser.consumSepChars(1, "-", forceSepChars);
	    	myDateParts.setDay(parser.consumDigits(2, 1));

	    	parser.consumSepChars(1, " T", forceSepChars);

	    	myDateParts.setHours(parser.consumDigits(2, 0));
	    	parser.consumSepChars(1, ":", forceSepChars);
	    	myDateParts.setMinutes(parser.consumDigits(2, 0));
	    	parser.consumSepChars(1, ":", forceSepChars);
	    	myDateParts.setSeconds(parser.consumDigits(2, 0));

	    	parser.consumSepChars(1, ".", false);
	    	myDateParts.setMs(parser.consumDigits(4, 0));

	    	myDateParts.setTimezone(parser.getRemaining());

    	} catch (IllegalArgumentException arrgh) {
    		throw new ParseException("Unable to parse ISO date in input string : " + parser + " (" + arrgh.getMessage() + ")", parser.getPosition());
    	}

    	return myDateParts.toDate();

    }

}
