package org.csvtools.base;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.util.List;

import org.csvtools.parsers.CsvFileParser;
import org.csvtools.writers.CsvFileWriter;

/**
 * CSVFile is a class used to handle <a href="http://en.wikipedia.org/wiki/Comma-separated_values">Comma-Separated Values</a> files.
 * <p>
 * It is abstract because it is the base class used for {@link CsvFileParser} and {@link CsvFileWriter}
 * so you should use one of these (or both) according on what you need to do.
 *
 * @author  Fabrizio Fazzino
 * @version %I%, %G%
 */
public abstract class CsvWriter {

	/**
	 * The default char used as field separator.
	 */
	protected static final char DEFAULT_FIELD_SEPARATOR = ',';

	/**
	 * The default char used as text qualifier
	 */
	protected static final char DEFAULT_TEXT_QUALIFIER = '"';

	/**
	 * The default String used as the Line Terminator
	 */
	protected static final String DEFAULT_LINE_TERMINATOR = "\r\n";

	/**
	 * The current char used as field separator.
	 */
	protected char fieldSeparator;

	/**
	 * The current char used as text qualifier.
	 */
	protected char textQualifier;

	/**
	 * The current String used as the line terminator.
	 */
	protected String lineTerminator = DEFAULT_LINE_TERMINATOR;

	/**
	 * CSVFile constructor with the default field separator and text qualifier.
	 */
	public CsvWriter() {
		this(DEFAULT_FIELD_SEPARATOR, DEFAULT_TEXT_QUALIFIER);
	}

	/**
	 * CSVFile constructor with a given field separator and the default text qualifier.
	 *
	 * @param sep The field separator to be used; overwrites the default one
	 */
	public CsvWriter(char sep) {
		this(sep, DEFAULT_TEXT_QUALIFIER);
	}

	/**
	 * CSVFile constructor with given field separator and text qualifier.
	 *
	 * @param sep  The field separator to be used; overwrites the default one
	 * @param qual The text qualifier to be used; overwrites the default one
	 */
	public CsvWriter(char sep, char qual) {
		setFieldSeparator(sep);
		setTextQualifier(qual);
	}

	/**
	 * Set the current field separator.
	 *
	 * @param sep The new field separator to be used; overwrites the old one
	 */
	public void setFieldSeparator(char sep) {
		fieldSeparator = sep;
	}

	/**
	 * Set the current text qualifier.
	 *
	 * @param qual The new text qualifier to be used; overwrites the old one
	 */
	public void setTextQualifier(char qual) {
		textQualifier = qual;
	}

	/**
	 * Get the current line terminator.
	 *
	 * @return The String containing the current field separator
	 */
	public String getLineTerminator() {
		return lineTerminator;
	}

	/**
	 * Set the current line terminator.
	 *
	 * @param term The new line terminator to be used; overwrites the old one
	 */
	public void setLineTerminator(String term) {
		this.lineTerminator = term;
	}

	/**
	 * Get the current field separator.
	 *
	 * @return The char containing the current field separator
	 */
	public char getFieldSeparator() {
		return fieldSeparator;
	}

	/**
	 * Get the current text qualifier.
	 *
	 * @return The char containing the current text qualifier
	 */
	public char getTextQualifier() {
		return textQualifier;
	}

	/**
	 * Join the fields and write them as a new line to the CSV file.
	 *
	 * @param fields The vector of strings containing the fields
	 */
	protected void writeLine(List<String> fields, OutputStream out)
	throws IOException {

		for (int i = 0, len = fields.size(); i < len; i++) {
			if (i > 0) {
				out.write(fieldSeparator);
			}
			out.write((textQualifier + fields.get(i) + textQualifier)
					.getBytes());
		}
		out.write(lineTerminator.getBytes());
	}

	protected void writeLine(List<String> fields, Writer out)
	throws IOException {

		for (int i = 0, len = fields.size(); i < len; i++) {
			if (i > 0) {
				out.write(fieldSeparator);
			}
			out.write(textQualifier + fields.get(i) + textQualifier);
		}
		out.write(lineTerminator);
	}
}
