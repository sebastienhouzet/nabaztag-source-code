package org.csvtools.writers;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.csvtools.base.CsvWriter;

/**
 * CSVFileWriter is a class derived from CSVFile used to format some fields into a new CSV file.
 *
 * @author  Fabrizio Fazzino
 * @version %I%, %G%
 */
public class CsvStreamWriter extends CsvWriter {
	/**
	 * The print writer linked to the CSV file to be written.
	 */
	protected OutputStream out;

	/**
	 * CSVFileWriter constructor just need the name of the CSV file that will be written.
	 *
	 * @param  outputFileName The name of the CSV file to be opened for writing
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvStreamWriter(OutputStream out) throws IOException {
		super();
		this.out = out;
	}

	/**
	 * CSVFileWriter constructor with a given field separator.
	 *
	 * @param outputFileName  The name of the CSV file to be opened for reading
	 * @param sep             The field separator to be used; overwrites the default one
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvStreamWriter(OutputStream out, char sep) throws IOException {
		super(sep);
		this.out = out;
	}

	/**
	 * CSVFileWriter constructor with given field separator and text qualifier.
	 *
	 * @param outputFileName  The name of the CSV file to be opened for reading
	 * @param sep             The field separator to be used; overwrites the default one
	 * @param qual            The text qualifier to be used; overwrites the default one
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvStreamWriter(OutputStream out, char sep, char qual)
	throws IOException {
		super(sep, qual);
		this.out = out;
	}

	/**
	 * Close the output CSV file.
	 *
	 * @throws IOException If an error occurs while closing the file
	 */
	public void close() {
		IOUtils.closeQuietly(out);
	}

	/**
	 * Join the fields and write them as a new line to the CSV file.
	 *
	 * @param fields The vector of strings containing the fields
	 */
	public void writeFields(List<String> fields) throws IOException {
		super.writeLine(fields, out);
	}

	/**
	 * Join the fields and write them as a new line to the CSV file.
	 *
	 * @param fields The vector of strings containing the fields
	 */
	public void writeFields(String... fields) throws IOException {
		super.writeLine(Arrays.asList(fields), out);
	}
}
