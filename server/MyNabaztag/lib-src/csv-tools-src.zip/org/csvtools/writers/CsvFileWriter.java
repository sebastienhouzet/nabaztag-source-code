package org.csvtools.writers;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.csvtools.base.CsvWriter;

/**
 * CSVFileWriter is a class derived from CSVFile used to format some fields into a new CSV file.
 *
 * @author  Fabrizio Fazzino
 * @version %I%, %G%
 */
public class CsvFileWriter extends CsvWriter {
	/**
	 * The print writer linked to the CSV file to be written.
	 */
	protected PrintWriter out;

	/**
	 * CSVFileWriter constructor just need the name of the CSV file that will be written.
	 *
	 * @param  outputFileName The name of the CSV file to be opened for writing
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvFileWriter(String outputFileName) throws IOException {
		super();
		out = new PrintWriter(new FileWriter(outputFileName));
	}

	/**
	 * CSVFileWriter constructor just need the name of the CSV file that will be written.
	 *
	 * @param  outputFile The CSV file to be opened for writing
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvFileWriter(File outputFile) throws IOException {
		super();
		out = new PrintWriter(new FileWriter(outputFile));
	}

	/**
	 * CSVFileWriter constructor with a given field separator.
	 *
	 * @param outputFileName  The name of the CSV file to be written
	 * @param sep             The field separator to be used; overwrites the default one
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvFileWriter(String outputFileName, char sep) throws IOException {
		super(sep);
		out = new PrintWriter(new FileWriter(outputFileName));
	}


	/**
	 * CSVFileWriter constructor with a given field separator.
	 *
	 * @param outputFile  The CSV file to be written
	 * @param sep             The field separator to be used; overwrites the default one
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvFileWriter(File outputFile, char sep) throws IOException {
		super(sep);
		out = new PrintWriter(new FileWriter(outputFile));
	}

	/**
	 * CSVFileWriter constructor with given field separator and text qualifier.
	 *
	 * @param outputFileName  The name of the CSV file to be written
	 * @param sep             The field separator to be used; overwrites the default one
	 * @param qual            The text qualifier to be used; overwrites the default one
	 * @throws IOException    If an error occurs while creating the file
	 */
	public CsvFileWriter(String outputFileName, char sep, char qual) throws IOException {
		super(sep, qual);
		out = new PrintWriter(new FileWriter(outputFileName));
	}

	/**
	 * Close the output CSV file.
	 *
	 * @throws IOException If an error occurs while closing the file
	 */
	public void close() {
		IOUtils.closeQuietly(out);
	}

	/**
	 * Join the fields and write them as a new line to the CSV file.
	 *
	 * @param fields The vector of strings containing the fields
	 */
	public void writeFields(List<String> fields) throws IOException {
		super.writeLine(fields, out);
	}

	/**
	 * Join the fields and write them as a new line to the CSV file.
	 *
	 * @param fields The vector of strings containing the fields
	 */
	public void writeFields(String... fields) throws IOException {
		super.writeLine(Arrays.asList(fields), out);
	}
}
