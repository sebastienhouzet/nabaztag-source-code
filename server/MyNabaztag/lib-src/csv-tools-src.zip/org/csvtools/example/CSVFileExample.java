package org.csvtools.example;
import java.util.*;
import java.io.*;

import org.csvtools.parsers.*;
import org.csvtools.writers.*;

public class CSVFileExample {

	
	
	public static void main(String[] args) throws FileNotFoundException,IOException {
	
//		 really close to the original example...
		CsvFileParser in = new CsvFileParser("csv_in.txt", ';', '"');
		CsvFileWriter out = new CsvFileWriter("csv_out.txt", ',', '\'');
		Vector<String> fields = in.readVectorLine();
		while(fields.size()!= 0) {
			out.writeFields(fields);
			
			fields = in.readVectorLine();
		}
		in.close();
		out.close();
		
		
		
		//uses streams instead of file names...
		CsvStreamParser sin = new CsvStreamParser(new FileInputStream("csv_in.txt"), ';', '"');
		CsvStreamWriter sout = new CsvStreamWriter(System.out,',', '\'');
		ArrayList<String> sfields = sin.readArrayListLine();
		while(sfields.size()!= 0) {
			sout.writeFields(sfields);
			sfields = sin.readArrayListLine();
		}
		sin.close();
		sout.close();
	}
	
}

